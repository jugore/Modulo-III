import { Data } from './data.model';

describe('Data', () => {
  it('should create an instance', () => {
    expect(new Data()).toBeTruthy();
  });
});
