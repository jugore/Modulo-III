import { Station } from './station.model';

describe('Station', () => {
  it('should create an instance', () => {
    expect(new Station()).toBeTruthy();
  });
});
