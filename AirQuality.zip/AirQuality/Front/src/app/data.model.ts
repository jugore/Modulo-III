export class Data {
    constructor(
        public name: string,
        public geo: object,
        public url: string,
        public country: string,
    ){

    } 
}
